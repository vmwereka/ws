<?php
require_once '../include/common.php';

$server->requestToken();
